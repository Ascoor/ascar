<?php
$con=mysqli_connect("localhost:3306", "root", "", "hany");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
