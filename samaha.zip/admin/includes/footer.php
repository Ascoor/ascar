<!--footer-->
    <div class="footer">
       <p>Askar Technological solutions copyright 2022</p>
    </div>
        <!--//footer-->