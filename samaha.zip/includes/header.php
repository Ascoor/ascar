<nav class="navbar navbar-expand-lg navbar-dark  bg-black">
  <a class="navbar-brand" href="index.php">Hany Samaha Brber Shop</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">الصفحة الرئيسية<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="services.php">الخدمات</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">من نحن</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">تواصل معنا</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="admin/index.php">النظام</a>
      </li>
    </ul>
  </div>
  
</nav>