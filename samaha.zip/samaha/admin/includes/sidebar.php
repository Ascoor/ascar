  <div class=" sidebar" role="navigation">
            <div class="navbar-collapse">
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
          <ul class="nav" id="side-menu">
              <li>
              <a href="test.php"><i class="fa fa-scissors nav_icon"></i>إضافة حجز</a>
            </li>
            <li>
          <a href="add-services.php"><i class="fa fa-cogs nav_icon"></i>الخدمات<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="add-services.php">إضافة خدمة</a>
                </li>
                <li>
                  <a href="manage-services.php">إدارة الخدمات</a>
                </li>
              </ul>
              <!-- /nav-second-level -->
           
          
            <li>
              <a href="all-appointment.php"><i class="fa fa-check-square-o nav_icon"></i>الحجوزات<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="all-appointment.php">جميع الحجوزات</a>
                </li>
                <li>
                  <a href="new-appointment.php">حجز جديد</a>
                </li>
                <li>
                  <a href="accepted-appointment.php">حجوزات منفذة</a>
                </li>
                <li>
                  <a href="rejected-appointment.php">حجوزات ملغاه</a>
                </li>
              </ul>
              <!-- //nav-second-level -->
            </li>
           
        
            <li>
              <a href="add-customer.php" class="chart-nav"><i class="fa fa-user nav_icon"></i>إضافة عميل</a>
            </li>
             <li>
              <a href="customer-list.php" class="chart-nav"><i class="fa fa-users nav_icon"></i>قائمة العملاء</a>
            </li>
              <li>
              <a href="#"><i class="fa fa-check-square-o nav_icon"></i>تقارير<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                 <li><a href="bwdates-reports-ds.php">تقرير عن فترة </a></li>
                   
                    <li><a href="sales-reports.php">تقارير المبيعات</a></li>
              </ul>
              <!-- //nav-second-level -->
            </li>

    <li>
              <a href="invoices.php" class="chart-nav"><i class="fa fa-file-text-o nav_icon"></i>الفواتير</a>
            </li>
            <li>
              <a href="search-appointment.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>بحث عن عميل</a>
            </li>
            <li>
              <a href="search-invoices.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>بحث عن فاتورة</a>
            </li>
          
          </ul>
          <div class="clearfix"> </div>
          <!-- //sidebar-collapse -->
        </nav>
      </div>
    </div>