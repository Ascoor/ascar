<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Firend extends Model
{
    protected $fillable = [ 'firend_name','firend_age','bio','is_approved'];
}
