<h1>index Kirkuk</h1>



@foreach ($muhammed as $item)
<h2>{{$item}}</h2>
@endforeach
